# AIMO Mathematical Reasoning

A curated collection of inference-pipeline and prompt/configuration experiments related to mathematical reasoning for the AI Mathematical Olympiad (AIMO) Progress Prize 2. The repository emphasizes model testing, inference behavior, answer extraction, and evaluation workflow.

## Notebooks

1. **AIMO2 inference pipeline** — multi-candidate reasoning and answer-selection workflow.
2. **Qwen 14B prompt experiments** — prompt-prefix and generation-pipeline experiments.
3. **AutoRound inference configuration (V2 source notebook)** — a quantized-model inference configuration using vLLM.
4. **AutoRound inference baseline** — a separate model artifact/configuration for comparison.
5. **Qwen 7B prompt evaluation** — prompt and candidate-generation experiments.

## Important limitations

- These notebooks were developed in a Kaggle/GPU environment and may depend on Kaggle input datasets/model artifacts, GPU hardware, and specific versions of vLLM or other packages. They are not guaranteed to run unchanged on a local machine.
- Saved generation logs demonstrate that code was executed in the original environment; they do **not**, by themselves, establish a validated accuracy score or prove that one configuration outperforms another.
- Review the answer-extraction and answer-selection logic before relying on reported predictions. In particular, verify fallback behavior, modulo handling, and any competition-environment shortcuts.
- Do not interpret this repository as claiming sole authorship of the underlying models. Contributions should be described accurately as testing, evaluation, prompt/inference experimentation, and related work, with model authors and source notebooks credited.

## Original sources and attribution

The selected notebooks are based on work associated with the Kaggle account `rob1080ti`. Preserve source attribution and the applicable original license/terms when redistributing or modifying these notebooks.

- AutoRound source notebook, earlier version: https://www.kaggle.com/code/rob1080ti/14b-autoround-tuned-test?scriptVersionId=227496306
- AutoRound source notebook, later version: https://www.kaggle.com/code/rob1080ti/14b-autoround-tuned-test?scriptVersionId=227833672
- Kaggle competition: https://www.kaggle.com/competitions/ai-mathematical-olympiad-progress-prize-2

Other source notebook links and contributor credits should be added before public release. A license file has intentionally not been added yet; verify the original notebook licenses and redistribution permissions first.

## Suggested next steps

1. Add the original Kaggle links and contributor credits for each notebook.
2. Audit and document all environment-specific shortcuts and answer-selection assumptions.
3. Add reproducible evaluation tests with known-answer problems before reporting accuracy or comparing configurations.
4. Pin compatible dependencies and record the GPU/runtime assumptions.
