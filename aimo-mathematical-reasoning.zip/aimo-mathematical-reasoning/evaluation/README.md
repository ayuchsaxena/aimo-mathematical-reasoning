# Evaluation plan

This directory is reserved for a reproducible evaluation harness. Before reporting results, define a fixed set of known-answer problems and measure at least:

- exact-answer accuracy
- answer-extraction success rate
- invalid/empty prediction rate
- latency per problem and per candidate
- agreement across multiple generated candidates

Record model artifact, prompt, decoding settings, random seed, hardware, software versions, and the exact evaluation dataset. No benchmark metrics are claimed yet.
